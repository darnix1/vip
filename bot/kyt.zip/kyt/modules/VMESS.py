from agin import *


@bot.on(events.CallbackQuery(data=b'vmess-trial'))
async def vmesstrial(event):
		async def vmesstrial_(event):
			z = db.execute("SELECT buttonname FROM vmess").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
				param = f":6969/trial-vmess"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(1),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 3:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» UUID        :** `{z["id"]}`
**» AlterId     :** `{z["aid"]}`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `{z["path"]}`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{x[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{x[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{x[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					elif len(list(x)) == 2:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» UUID        :** `{z["id"]}`
**» AlterId     :** `{z["aid"]}`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `{z["path"]}`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{x[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{x[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{x[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					await event.respond(msg)

		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await vmesstrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await vmesstrial_(event)
		
		
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def vmess(event):
	async def vmess_(event):
		z = db.execute("SELECT buttonname FROM vmess").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga7 = db.execute("SELECT harga7 FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		harga = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		#namaserver = db.execute("SELECT namaserver FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		quota = db.execute("SELECT quota FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		msg = f"""

** INFORMASI SERVER VMESS **

** Server Name:** `{buttonname}`
** ISP:** `{z["isp"]}`
** Country:** `{z["country"]}`
** Domain:** `{domain}`
** Harga 7 Day:** `{harga7}`
** Harga 30 Day:** `{harga}`
** Total Akun Dibuat:** `{cont}/{lim}`


** Pilih Ya Untuk Lanjut...!! **

"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("7 Day","7")],

[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga7:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "7":
					min = harga7
				if exp == "30":
					min = harga
				param = f":6969/create-vmess?user={user}&quota={quota}&limitip={limitip}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 3:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» UUID        :** `{z["id"]}`
**» AlterId     :** `{z["aid"]}`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `{z["path"]}`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{x[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{x[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{x[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{domain}:81/vmess-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					elif len(list(x)) == 2:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» UUID        :** `{z["id"]}`
**» AlterId     :** `{z["aid"]}`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `{z["path"]}`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{x[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{x[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{x[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{domain}:81/vmess-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"VMess",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await vmess_(event)
	else:
		await vmess_(event)
		
		
@bot.on(events.CallbackQuery(data=b'vmess-menu'))
async def vmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namas()
	har = hargas()
	harr = hargass()
	serv = []
	for x, y, a in zip(ser, har, harr):
		print(x, y, a)
		serv.append(f"** {x}  7 Day** `Rp.{a}`\n")
		serv.append(f"** {x}  30 Day** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
VMess Menu
- VMess gRPC TLS
- VMess WS Non-TLS
- VMess WS TLS

Rules:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned

Info Harga :
** **
{"".join(serv)}


"""
			await event.edit(msg, buttons=[
[Button.inline(" CREATED VMESS ","create-vmess"),
Button.inline(" CREATED TRIAL VMESS ","vmess-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
VMess Menu
- VMess gRPC TLS
- VMess WS Non-TLS
- VMess WS TLS

Rules:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned

Info Harga :
** **
{"".join(serv)}


"""
		await event.edit(msg, buttons=[
[Button.inline(" CREATED VMESS ","create-vmess"),
Button.inline(" CREATED TRIAL VMESS ","vmess-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
