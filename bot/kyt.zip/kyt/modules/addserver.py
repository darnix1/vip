from agin import *

@bot.on(events.CallbackQuery(data=b'addssh'))
async def ssh(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga7:
			await event.respond("**Harga 7 Day:**")
			harga7 = harga7.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga7 = await harga7
			harga7 = harga7.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga 30 Day:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as ns:
			await event.respond("**Ns Domain: **")
			ns = ns.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ns = await ns
			ns = ns.message.message
		async with bot.conversation(event.chat_id) as limitip:
			await event.respond("**Limit IP: **")
			limitip = limitip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limitip = await limitip
			limitip = limitip.message.message
		async with bot.conversation(event.chat_id) as pubkey:
			await event.respond("**Pub Key Slow Keong: **")
			pubkey = pubkey.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pubkey = await pubkey
			pubkey = pubkey.message.message

		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		z = db.execute("INSERT INTO ssh (buttonname,harga7, harga,domain,ns,limitip,limcounted,pubkey) VALUES (?,?,?,?,?,?,?,?)",
		(buttonname,harga7,harga,domain,ns,limitip,limcounted,pubkey))
		db.commit()
		msg = f"""

**━━━━━━━━━━━━━━━━**
**⟨ Add Server SSH Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 NS Domain:** `{ns}`
**🔰 harga 7 Day:** `{harga7}`
**🔰 harga 30 Day:** `{harga}`
**🔰 Limit IP:** `{limitip}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
"""
		await event.respond(msg)


@bot.on(events.CallbackQuery(data=b'addtrojanws'))
async def trojanws(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga7:
			await event.respond("**Harga 7 Day:**")
			harga7 = harga7.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga7 = await harga7
			harga7 = harga7.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga 30 Day:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as quota:
			await event.respond("**Quota: **")
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = await quota
			quota = quota.message.message
		async with bot.conversation(event.chat_id) as limitip:
			await event.respond("**Limit IP: **")
			limitip = limitip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limitip = await limitip
			limitip = limitip.message.message
		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		z = db.execute("INSERT INTO trojanws (buttonname,harga7,harga,domain,quota,limitip,limcounted) VALUES (?,?,?,?,?,?,?)",
		(buttonname,harga7,harga,domain,quota,limitip,limcounted))
		db.commit()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Add Server Trojan-WS Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 harga 7 Day:** `{harga7}`
**🔰 harga 30 Day:** `{harga}`
**🔰 Quota:** `{quota}`
**🔰 Limit IP:** `{limitip}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
"""
		await event.respond(msg)



@bot.on(events.CallbackQuery(data=b'addvmess'))
async def vmess(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga7:
			await event.respond("**Harga 7 Day:**")
			harga7 = harga7.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga7 = await harga7
			harga7 = harga7.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga 30 Day:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as quota:
			await event.respond("**Quota: **")
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = await quota
			quota = quota.message.message
		async with bot.conversation(event.chat_id) as limitip:
			await event.respond("**Limit IP: **")
			limitip = limitip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limitip = await limitip
			limitip = limitip.message.message
		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		z = db.execute("INSERT INTO vmess (buttonname,harga7,harga,domain,quota,limitip,limcounted) VALUES (?,?,?,?,?,?,?)",
		(buttonname,harga7,harga,domain,quota,limitip,limcounted))
		db.commit()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Add Server Vmess Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 harga 7 Day:** `{harga7}`
**🔰 harga 30 Day:** `{harga}`
**🔰 Quota:** `{quota}`
**🔰 Limit IP:** `{limitip}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
"""
		await event.respond(msg)


@bot.on(events.CallbackQuery(data=b'addgfw'))
async def gfw(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		z = db.execute("INSERT INTO trojangfw (buttonname,harga,domain,limcounted) VALUES (?,?,?,?)",
		(buttonname,harga,domain,limcounted))
		db.commit()
		await event.respond(f"""
**━━━━━━━━━━━━━━━━**
**⟨ Add Server Trojan-GFW Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 harga:** `{harga}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
""")

@bot.on(events.CallbackQuery(data=b'addtrg'))
async def trg(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		z = db.execute("INSERT INTO trojango (buttonname,harga,domain,limcounted) VALUES (?,?,?,?)",
		(buttonname,harga,domain,limcounted))
		db.commit()
		await event.respond(f"""
**━━━━━━━━━━━━━━━━**
**⟨ Add Server Trojan-GO Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 harga:** `{harga}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
""")

@bot.on(events.CallbackQuery(data=b'svmenu'))
async def svmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if val == "false":
		if sender.id in a:
			await event.edit(buttons=[
[Button.inline(" Add SSH Server  ","addssh"),
Button.inline(" Add Vmess Server ","addvmess")],
[Button.inline(" Add Vless Server ","addvless")],
[Button.inline(" Add Trojan gRPC / WS Server ","addtrojanws")],
[Button.inline(" Add Trojan-GFW Server ","addgfw"),
Button.inline(" Add Trojan-GO Server ","addtrg")],
[Button.inline("🔙 Back To Menu",f"menu")]])
