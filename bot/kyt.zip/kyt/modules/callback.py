from agin import *

@app.route("/callback", methods=["POST"])
async def callback():
    print("Callback function called")
    received_signature = request.headers.get("X-Callback-Signature")
    signStr = request.data.decode('utf-8')
    
    if not signStr:
        return "Empty JSON data received"
    
    print("Received JSON data:", signStr)  # Cetak data JSON yang diterima untuk di-debug
    
    try:
        js = json.loads(signStr)
    except json.JSONDecodeError as e:
        return "Invalid JSON data received"
    
    # Menghitung tanda tangan dari data yang diterima
    calculated_signature = hmac.new(bytes(privateKey, 'latin-1'), bytes(signStr, 'latin-1'), hashlib.sha256).hexdigest()
    
    if received_signature == calculated_signature:
        # Tanda tangan valid, lanjutkan pemrosesan callback
        db = get_db()
        
        payload = { "reference": js["reference"] }
        headers = { "Authorization": "Bearer " + apiKey }
        result = requests.get("https://tripay.co.id/api/transaction/detail", params=payload, headers=headers)
        response = result.text
        js = json.loads(response)
        status = js["data"]["status"]
        
        signDb = db.execute("SELECT sign FROM tripay WHERE sign = ?", (received_signature,)).fetchone()
        
        if status == "PAID" and signDb is None:
            fee = int(js["data"]["fee_customer"])
            db.execute("INSERT INTO tripay (sign) VALUES (?)",(received_signature,))
            email = js["data"]["customer_email"]
            saldo = int(js["data"]["amount"])
            saldo = saldo - fee
            bonus = 5000 if saldo >= 17000 else 0 #saldo * 0.10
            saldo = saldo + bonus
            current_saldo = db.execute("SELECT saldo FROM user WHERE email = ?", (email,)).fetchone()[0]
            db.execute("UPDATE user SET saldo = ? WHERE email = ?",(int(current_saldo)+int(saldo),email,))
            db.commit()

            # Kode yang Anda tambahkan
            dat = {
                "email": email,
                "balance": saldo
            }
            await notifpay(dat, event)
            
            return { "success": True }
        else:
            return "None"
    else:
        return "Invalid signature"

